set(crazyflie_transport_sources)
set(crazyflie_transport_requires)

idf_build_get_property(crazyflie_idf_target IDF_TARGET)

# Component requirements are resolved before project Kconfig values are fully
# available.  Use fixed SoC capabilities here and Kconfig only for sources.
if(NOT crazyflie_idf_target STREQUAL "esp32p4")
  list(APPEND crazyflie_transport_requires wifi esp_wifi)
endif()

if(NOT crazyflie_idf_target STREQUAL "esp32p4" AND
   NOT crazyflie_idf_target STREQUAL "esp32s31")
  list(APPEND crazyflie_transport_requires espressif__esp-now)
endif()

if(CONFIG_TRANSPORT_NATIVE_WIFI)
  list(APPEND crazyflie_transport_sources "./hal/src/wifilink.c")
elseif(CONFIG_TRANSPORT_REMOTE_WIFI)
  list(APPEND crazyflie_transport_sources "./hal/src/wifilink.c")
endif()

if(CONFIG_ESPNOW_CONTROL)
  list(APPEND crazyflie_transport_sources "./hal/src/espnow_ctrl.c")
endif()

idf_component_register(SRCS "./hal/src/buzzer.c" 
                "./hal/src/freeRTOSdebug.c" 
                "./hal/src/ledseq.c" 
                "./hal/src/pm_esplane.c" 
                "./hal/src/sensors_mpu6050_hm5883L_ms5611.c" 
                "./hal/src/sensors.c" 
                "./hal/src/transport.c"
                "./hal/src/usec_time.c" 
                ${crazyflie_transport_sources}
                "./modules/src/app_handler.c" 
                "./modules/src/app_channel.c" 
                "./modules/src/attitude_pid_controller.c"
                "./modules/src/comm.c"
                "./modules/src/commander.c"
                "./modules/src/console.c"
                "./modules/src/controller_indi.c"
                "./modules/src/controller_mellinger.c"
                "./modules/src/controller_pid.c"
                "./modules/src/controller.c"
                "./modules/src/crtp_commander_generic.c"
                "./modules/src/crtp_commander_high_level.c"
                "./modules/src/crtp_commander_rpyt.c"
                "./modules/src/crtp_commander.c"
                "./modules/src/crtp.c"
                "./modules/src/crtpservice.c"
                "./modules/src/estimator_complementary.c"
                "./modules/src/estimator_kalman.c"
                "./modules/src/estimator.c"
                "./modules/src/kalman_core.c"
                "./modules/src/kalman_supervisor.c"
                "./modules/src/log.c"
                "./modules/src/mem.c"
                "./modules/src/msp.c"
                "./modules/src/outlierFilter.c"
                "./modules/src/param.c"
                "./modules/src/pid.c"
                "./modules/src/planner.c"
                "./modules/src/platformservice.c"
                "./modules/src/position_controller_indi.c"
                "./modules/src/position_controller_pid.c"
                "./modules/src/position_estimator_altitude.c"
                "./modules/src/power_distribution_stock.c"
                "./modules/src/pptraj_compressed.c"
                "./modules/src/pptraj.c"
                "./modules/src/queuemonitor.c"
                "./modules/src/range.c"
                "./modules/src/sensfusion6.c"
                "./modules/src/sitaw.c"
                "./modules/src/sound_cf2.c"
                "./modules/src/stabilizer.c"
                "./modules/src/sysload.c"
                "./modules/src/system.c"
                "./modules/src/trigger.c"
                "./modules/src/worker.c"
                "./utils/src/abort.c"
                "./utils/src/cfassert.c"
                "./utils/src/clockCorrectionEngine.c"
                "./utils/src/configblockeeprom.c"
                "./utils/src/cpuid.c"
                "./utils/src/crc_bosch.c"
                "./utils/src/crc.c"
                "./utils/src/debug_cf.c"
                "./utils/src/eprintf.c"
                "./utils/src/filter.c"
                "./utils/src/FreeRTOS-openocd.c"
                "./utils/src/num.c"
                "./utils/src/sleepus.c"
                "./utils/src/statsCnt.c"
                "./utils/src/version.c"
                "./utils/src/rateSupervisor.c"
                INCLUDE_DIRS "./hal/interface" "./modules/interface" "./utils/interface"
                REQUIRES i2c_bus deck mpu6050 ms5611 hmc5883l pmw3901 vl53l1 vl53l0 platform config led eeprom dsp_lib motors adc esp_timer esp_driver_gpio ${crazyflie_transport_requires})

idf_component_get_property( FREERTOS_ORIG_INCLUDE_PATH freertos ORIG_INCLUDE_PATH)
target_include_directories(${COMPONENT_TARGET} PUBLIC
  "${FREERTOS_ORIG_INCLUDE_PATH}"
)
target_compile_options(${COMPONENT_LIB} PRIVATE "-fno-strict-aliasing"
                                                "-Wno-error=stringop-truncation"
                                                "-Wno-absolute-value"
                                                "-Wno-address-of-packed-member"
                                                "-Wno-stringop-truncation"
                                                "-Wno-format")
